import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class Server {
    private static final int PORT = 12345;
    private static Set<ClientHandler> clientHandlers = new HashSet<>();
    private static Map<String, String> userDatabase = new HashMap<>(); // Stores user credentials

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is listening on port " + PORT);

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connected: " + socket.getInetAddress());
                ClientHandler clientHandler = new ClientHandler(socket);
                clientHandlers.add(clientHandler);
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }

    static class ClientHandler implements Runnable {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private String username;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                // User Authentication
                out.println("Welcome to the chat server. Please type 'login' to login or 'create' to create an account.");
                String command = in.readLine();
                
                if ("create".equalsIgnoreCase(command)) {
                    createAccount();
                } else if ("login".equalsIgnoreCase(command)) {
                    login();
                }

                // Chat Loop
                String message;
                while ((message = in.readLine()) != null) {
                    if (message.equalsIgnoreCase("logout")) {
                        out.println(username + " has logged out.");
                        break;
                    }
                    broadcastMessage(username + ": " + message);
                }
            } catch (IOException e) {
                System.out.println("Error with client communication: " + e.getMessage());
            } finally {
                try {
                    socket.close();
                    clientHandlers.remove(this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void createAccount() throws IOException {
            out.println("Please enter your desired username: ");
            String newUsername = in.readLine();

            if (userDatabase.containsKey(newUsername)) {
                out.println("Username already exists. Try again with a different one.");
                return;
            }

            out.println("Please enter your password: ");
            String password = in.readLine();

            userDatabase.put(newUsername, password);
            out.println("Account created successfully! You can now log in.");
        }

        private void login() throws IOException {
            out.println("Enter your username: ");
            String usernameInput = in.readLine();

            if (!userDatabase.containsKey(usernameInput)) {
                out.println("Username does not exist. Try again.");
                return;
            }

            out.println("Enter your password: ");
            String passwordInput = in.readLine();

            if (!userDatabase.get(usernameInput).equals(passwordInput)) {
                out.println("Incorrect password. Try again.");
                return;
            }

            username = usernameInput;
            out.println("Logged in successfully as " + username);
            broadcastMessage(username + " has logged in.");
        }

        private void broadcastMessage(String message) {
            for (ClientHandler clientHandler : clientHandlers) {
                clientHandler.out.println(message);
            }
        }
    }
}
