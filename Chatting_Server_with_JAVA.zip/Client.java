import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class Client {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;
    private static Socket socket;
    private static PrintWriter out;
    private static BufferedReader in;
    private static JTextArea chatArea;
    private static JTextField messageField;
    private static String username;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Chat Client");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setLayout(new BorderLayout());

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        frame.add(new JScrollPane(chatArea), BorderLayout.CENTER);

        messageField = new JTextField();
        frame.add(messageField, BorderLayout.SOUTH);

        messageField.addActionListener(e -> sendMessage());

        JButton connectButton = new JButton("Connect");
        frame.add(connectButton, BorderLayout.NORTH);
        connectButton.addActionListener(e -> connect());

        frame.setVisible(true);
    }

    private static void connect() {
        try {
            socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // Receive the initial server message
            String serverMessage = in.readLine();
            chatArea.append(serverMessage + "\n");

            // Ask for login or account creation
            String command = JOptionPane.showInputDialog("Would you like to login or create an account? (login/create)");
            out.println(command);

            if ("create".equalsIgnoreCase(command)) {
                createAccount();
            } else if ("login".equalsIgnoreCase(command)) {
                login();
            }

            // Start receiving messages from the server
            new Thread(new ServerListener()).start();
        } catch (IOException e) {
            chatArea.append("Connection error: " + e.getMessage() + "\n");
        }
    }

    private static void createAccount() {
        String newUsername = JOptionPane.showInputDialog("Enter your desired username:");
        out.println(newUsername);
        String password = JOptionPane.showInputDialog("Enter your password:");
        out.println(password);
    }

    private static void login() {
        String usernameInput = JOptionPane.showInputDialog("Enter your username:");
        out.println(usernameInput);
        String passwordInput = JOptionPane.showInputDialog("Enter your password:");
        out.println(passwordInput);
    }

    private static void sendMessage() {
        String message = messageField.getText();
        if (!message.isEmpty()) {
            out.println(message);
            messageField.setText("");
        }
    }

    static class ServerListener implements Runnable {
        @Override
        public void run() {
            try {
                String serverMessage;
                while ((serverMessage = in.readLine()) != null) {
                    chatArea.append(serverMessage + "\n");
                }
            } catch (IOException e) {
                chatArea.append("Server connection lost: " + e.getMessage() + "\n");
            }
        }
    }
}
